#!/bin/bash

sudo docker-compose down

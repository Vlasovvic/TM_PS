#!/bin/bash
sudo docker-compose up

#-------------------------------------------------
УСТАНОВКА
1. перейти в installation
2. sudo ./install.sh
3. включить автозапуск при старте системы
sudo systemctl enable mbsrtu_server_py.service
4. файл конфигурации:
директория: /opt/poll_server_py/configurations
файл: config.json

#-------------------------------------------------
УПРАВЛЕНИЕ

1. узнать статус
systemctl status mbsrtu_server_py

2. остановить
sudo systemctl stop mbsrtu_server_py
или ручной
sudo /opt/poll_server_py/sbin/control.sh stop

3. запустить
sudo systemctl start mbsrtu_server_py
или ручной
sudo /opt/poll_server_py/sbin/control.sh start

4. посмотреть лог > (/opt/poll_server_py/logs)
tail /opt/poll_server_py/logs/*

#-------------------------------------------------
ДОПОЛНИТЕЛЬНО

1. sudo netstat -tunlp | grep python
